<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Post Create Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>['posts.store'],'method'=>'POST','files'=>'true','class'=>'widget-content nopadding']); ?>

                        <?php echo e(csrf_field()); ?>

                    <div class="control-group">
                        <label class="control-label">Turkish Menu Name :</label>
                        <div class="controls">
                            <select name="menu_id" class="span11">
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($menu->id); ?>"><?php echo e($menu->name_tr); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('menu_id')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('menu_id')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Turkish Sub Menu Name :</label>
                        <div class="controls">
                            <select name="submenu_id" class="span11">
                                <?php $__currentLoopData = $subMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subMenu->id); ?>"><?php echo e($subMenu->name_tr); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php if($errors->has('submenu_id')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('submenu_id')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Turkish Title :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="title_tr" value="<?php echo e(old('title_tr')); ?>" />
                        </div>
                        <?php if($errors->has('title_tr')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('title_tr')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Turkish Description</label>
                        <div class="controls">
                            <textarea style="height: 500px;" name="description_tr" id="description_tr" ><?php echo e(old('description_tr')); ?></textarea>
                        </div>
                        <?php if($errors->has('description_tr')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('description_tr')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Photo</label>
                        <div class="controls">
                            <input type="file" class="span11" name="photo_path" />
                            <?php if($errors->has('photo_path')): ?>
                                <p class="alert alert-danger">
                                    <?php echo e($errors->first('photo_path')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Video Embed Path :</label>
                        <p>For Exp: https://www.youtube.com/watch?v=<b>VIDEO_ID</b></p>
                        <div class="controls">
                            <input type="text" class="span11"  name="embed_video_path" value="<?php echo e(old('embed_video_path')); ?>" />
                        </div>
                        <?php if($errors->has('embed_video_path')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('embed_video_path')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/4.13.0/full/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'description_tr' );
</script>
<script>
    CKEDITOR.replace( 'description_eng' );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>