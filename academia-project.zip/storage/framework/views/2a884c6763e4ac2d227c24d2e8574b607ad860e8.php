<?php $__env->startSection('content'); ?>

    <div class="single_courcse">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6">
                    <div class="single_cos_item">
                        <h2 class="single_courcse_title"><?php echo e($news->title_tr); ?></h2>
                        <br>
                        <?php echo html_entity_decode(nl2br(e($news->description_tr))); ?>

                    </div>
                </div>
                <?php if(isset($news->photo_path)): ?>
                    <div class="col-md-4 col-sm-6">

                        <?php if($news->photo_path != '/storage/'): ?>
                            <div class="met-box">
                                <img src="<?php echo e($news->photo_path); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/frontend/news.blade.php ENDPATH**/ ?>