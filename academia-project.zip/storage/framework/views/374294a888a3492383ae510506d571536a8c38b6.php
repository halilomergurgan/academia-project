<?php $__env->startSection('content'); ?>
    <div class="teacher_area home-2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title">
                        <h3 class="module-title">
                            Deneyimli Öğretmen   <span>Kadromuz</span>
                        </h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <!--start teacher single  item -->
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-3 col-lg-4 col-sm-3" style="width: 5px;">
                    <div class="single_teacher_item" style="width: 350px; height: 400px;">
                        <div class="teacher_thumb">
                            <?php if($teacher->photo_path == '/storage/' || !isset($teacher->photo_path)): ?>
                                <img src="frontend/img/logo3.jpg" alt="" style="height: 350px; width: 350px;" />
                            <?php else: ?>
                                <img src="<?php echo e($teacher->photo_path); ?>" alt="" style="height: 350px; width: 350px;" />
                            <?php endif; ?>
                            <div class="thumb_text">
                                <h2><?php echo e($teacher->teach_name_tr); ?></h2>
                                <p><?php echo e($teacher->teach_title); ?></p>
                            </div>
                        </div>
                        <div class="teacher_content" style="padding: 0px 0px 0;">
                            <h2><?php echo e($teacher->teach_name_tr); ?></h2>
                            <span><?php echo e($teacher->teach_title); ?></span>
                            <?php echo strip_tags(htmlspecialchars_decode($teacher->teach_description_tr)); ?>

                            <div class="social_icons">
                                <?php if(isset($teacher->twitter)): ?>
                                    <a href="http://twitter.com/<?php echo e($teacher->twitter); ?>" class="tw"><i class="fa fa-twitter"></i></a>
                                <?php endif; ?>
                                <?php if(isset($teacher->facebook)): ?>
                                    <a href="http://facebook.com/<?php echo e($teacher->facebook); ?>" class="fb"><i class="fa fa-facebook"></i></a>
                                <?php endif; ?>
                                <?php if(isset($teacher->linkedin)): ?>
                                    <a href="http://linkedin.com/in/<?php echo e($teacher->linkedin); ?>" class="lin"><i class="fa fa-linkedin"></i></a>
                                <?php endif; ?>
                                <?php if(isset($teacher->web_site)): ?>
                                    <a href="https://<?php echo e($teacher->web_site); ?>" class="fa fa-globe"><i class="fa fa-globe"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!--End teacher single  item -->


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/frontend/teachers.blade.php ENDPATH**/ ?>