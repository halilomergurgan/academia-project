<?php $__env->startSection('content'); ?>

    <div style="float: right;margin: 20px 0px 5px 0;">
        <a href="<?php echo e(route('files.create')); ?>" class="btn btn-success"> File Create
        </a>
    </div>
    <div style="clear: both;">
    </div>
    <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-th"></i></span>
            <h5>Files Table</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Name</th>
                    <th>File</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr class="gradeX">
                        <td><?php echo e($file->file_name); ?></td>
                        <?php
                            if ($file->extension == 'xls'){
                                $file->extension = 'xls';
                            }
                             if ($file->extension == 'word'){
                                $file->extension = 'word';
                            }
                             if ($file->extension == 'pdf'){
                                $file->extension = 'pdf';
                            }
                            if ($file->extension == 'xlsx'){
                                $file->extension = 'xls';
                            }
                             if ($file->extension == 'docx'){
                                $file->extension = 'word';
                            }
                        ?>
                        <td style="text-align: center;">
                            <a href="<?php echo e($file->file_path); ?>" target="_blank"><img
                                    src="/admin/img/<?php echo e($file->extension); ?>.ico" style="height:50px; width:50px;">
                            </a>
                            <input type="text" value=<?php echo e(URL::to('/')); ?><?php echo e($file->file_path); ?> id="myInput<?php echo e($file->id); ?>">
                            <button class="btn btn-info icon-copy" onclick="myFunction(<?php echo e($file->id); ?>)"> Copy Link</button>
                        </td>

                        <?php echo Form::model($files,['route'=>['files.destroy',$file->id],'method'=>'DELETE']); ?>

                        <td class="center">
                            <button type="submit" class="btn btn-danger btn-mini"
                                    onclick="if (!confirm('Are you sure?')) { return false }"><span>Delete</span>
                            </button>
                        </td>
                        <?php echo Form::close(); ?>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/css/uniform.css"/>
    <link rel="stylesheet" href="/admin/css/select2.css"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="/admin/js/excanvas.min.js"></script>
    <script src="/admin/js/jquery.min.js"></script>
    <script src="/admin/js/jquery.ui.custom.js"></script>
    <script src="/admin/js/bootstrap.min.js"></script>
    <script src="/admin/js/jquery.dataTables.min.js"></script>
    <script src="/admin/js/matrix.tables.js"></script>

    <script>
        function myFunction(x) {
            var copyText = document.getElementById("myInput"+x);
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            document.execCommand("copy");
            alert("Copied the text: " + copyText.value);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/files/index.blade.php ENDPATH**/ ?>