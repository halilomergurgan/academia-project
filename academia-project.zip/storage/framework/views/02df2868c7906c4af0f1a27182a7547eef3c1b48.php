<?php $__env->startSection('content'); ?>

    <div class="about_area page">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title">
                        <h3 class="module-title about_titlea">
                            <?php echo html_entity_decode(nl2br(e($about[0]->title_tr))); ?>


                        </h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="content-inner">
                        <div class="content-desc">
                            <div class="">
                                <?php echo html_entity_decode(nl2br(e($about[0]->description_tr))); ?>


                            </div>
                        </div>
                    </div>
                </div>









            </div>
        </div>
    </div>

    <div class="breadcrumb-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb">
                        <ul>
                            <li><a href="/">Anasayfa</a> <i class="fa fa-angle-right"></i></li>
                            <li>Hakkımızda</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/frontend/about.blade.php ENDPATH**/ ?>