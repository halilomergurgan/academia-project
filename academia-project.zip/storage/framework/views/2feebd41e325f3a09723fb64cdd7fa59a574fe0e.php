<?php $__env->startSection('content'); ?>
    <div style="float: right;margin: 20px 0px 5px 0;">
        <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success"> Post Create
        </a>
    </div>
    <div style="clear: both;">
    </div>
    <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-th"></i></span>
            <h5>Post Table</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Turkish Menu Name</th>
                    <th>Turkish Sub Menu Name</th>
                    <th>Turkish Title</th>
                    <th>Description TR</th>
                    <th>Photo</th>
                    <th>Embed Video Path</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="gradeX">
                        <td><?php echo e($post->menu->name_tr); ?></td>
                        <td><?php echo e($post->subMenu->name_tr); ?></td>
                        <td><?php echo e($post->title_tr); ?></td>
                        <td><?php echo e(Str::limit($post->description_tr, 100)); ?></td>
                        <td><a href="<?php echo e($post->photo_path); ?>" target="_blank"><img src="<?php echo e($post->photo_path); ?>"
                                                                                   height="100" width="100"></a></td>
                        <td>
                            <iframe width="250" height="200"
                                    src="https://www.youtube.com/embed/<?php echo e($post->embed_video_path); ?>" frameborder="0"
                                    allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                    allowfullscreen></iframe>
                        </td>
                        <td class="center"><a href="<?php echo e(route('posts.edit',$post->id)); ?>"
                                              class="btn btn-success btn-mini">Edit</a>
                        </td>
                        <?php echo Form::model($posts,['route'=>['posts.destroy',$post->id],'method'=>'DELETE']); ?>

                        <td class="center">
                            <button type="submit" class="btn btn-danger btn-mini"
                                    onclick="if (!confirm('Are you sure?')) { return false }"><span>Delete</span>
                            </button>
                        </td>
                        <?php echo Form::close(); ?>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/css/uniform.css"/>
    <link rel="stylesheet" href="/admin/css/select2.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="/admin/js/excanvas.min.js"></script>
    <script src="/admin/js/jquery.min.js"></script>
    <script src="/admin/js/jquery.ui.custom.js"></script>
    <script src="/admin/js/bootstrap.min.js"></script>
    <script src="/admin/js/jquery.dataTables.min.js"></script>
    <script src="/admin/js/matrix.tables.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>