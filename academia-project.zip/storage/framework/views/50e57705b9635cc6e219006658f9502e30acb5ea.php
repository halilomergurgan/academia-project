<?php $__env->startSection('content'); ?>
    <div class="row-fluid">
        <div class="widget-box">
            <div class="widget-title bg_lg"><span class="icon"><i class="icon-signal"></i></span>
                <h5>Site Analytics</h5>
            </div>
            <div class="widget-content">
                <div class="row-fluid">
                    <div class="span12">
                        <ul class="site-stats">
                            <li class="bg_lh" style="background: #27a9e3;"><i class=""></i>
                                <strong><?php echo e($count['news']); ?></strong>
                                <small>Total News</small>
                            </li>
                            <li class="bg_lh" style="background: #27a9e3;"><i class=""></i>
                                <strong><?php echo e($count['slider']); ?></strong>
                                <small>Total Slider</small>
                            </li>
                            <li class="bg_lh" style="background: #27a9e3;"><i class=""></i>
                                <strong><?php echo e($count['courses']); ?></strong>
                                <small>Total Course</small>
                            </li>
                            <li class="bg_lh" style="background: #27a9e3;"><i class=""></i>
                                <strong><?php echo e($count['articles']); ?></strong>
                                <small>Total Article</small>
                            </li>
                            <li class="bg_lh" style="background: #27a9e3;"><i class=""></i>
                                <strong><?php echo e($count['magazines']); ?></strong>
                                <small>Total Magazine</small>
                            </li>
                            <li class="bg_lh" style="background: #27a9e3;"><i class=""></i>
                                <strong><?php echo e($count['teachers']); ?></strong>
                                <small>Total Teacher</small>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <h3 style="text-align: center;">Calendar</h3>

    <div id='calendar'></div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js'></script>
    <script>
        $(document).ready(function() {
            // page is now ready, initialize the calendar...
            $('#calendar').fullCalendar({
                // put your options and callbacks here
                events : [
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        title : '<?php echo e($task->name); ?>',
                        start : '<?php echo e($task->task_date); ?>',
                        url : '<?php echo e(route('tasks.edit', $task->id)); ?>'
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/index.blade.php ENDPATH**/ ?>