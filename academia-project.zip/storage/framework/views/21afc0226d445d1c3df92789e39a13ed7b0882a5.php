<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Menu Create Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>['menu.store'],'method'=>'POST','class'=>'widget-content nopadding']); ?>

                        <?php echo e(csrf_field()); ?>

                    <div class="control-group">
                        <label class="control-label">Turkish Menu Name :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="name_tr" value="<?php echo e(old('name_tr')); ?>" />
                        </div>
                        <?php if($errors->has('name_tr')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('name_tr')); ?>

                            </p>
                        <?php endif; ?>
                    </div> 
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/menu/create.blade.php ENDPATH**/ ?>