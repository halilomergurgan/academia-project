<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>About Edit Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::model($about,['route'=>['about.update',$about->id],'method'=>'PUT','files'=>'true','class'=>'widget-content nopadding']); ?>

                    <div class="control-group">
                        <label class="control-label">Turkish Title :</label>
                        <div class="controls">
                            <?php echo e(Form::textarea( 'title_tr', $about->title_tr, array('id' => 'title_tr'))); ?>

                        </div>
                    </div>

                    <div class="control-group">
                        <label class="control-label">Turkish Description</label>
                        <div class="controls">
                            <?php echo e(Form::textarea( 'description_tr', $about->description_tr, array('id' => 'description_tr'))); ?>


                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Video ID :</label>
                        <p>For Exp: https://www.youtube.com/watch?v=<b>VIDEO_ID</b></p>
                        <div class="controls">
                            <input type="text" class="span11" name="embed_video_path" value="<?php echo e($about->embed_video_path); ?>" />
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.ckeditor.com/4.13.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'description_tr' );
    </script>
    <script>
        CKEDITOR.replace( 'description_eng' );
    </script>
    <script>
        CKEDITOR.replace( 'title_tr' );
    </script>
    <script>
        CKEDITOR.replace( 'title_eng' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/about/edit.blade.php ENDPATH**/ ?>