<?php $__env->startSection('content'); ?>
    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Contact Edit Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::model($contact,['route'=>['contact.update',$contact->id],'method'=>'PUT','files'=>'true','class'=>'widget-content nopadding']); ?>

                    <div class="control-group">
                        <label class="control-label">Phone:</label>
                        <div class="controls">
                            <?php echo e(Form::textarea( 'phone', $contact->phone, array('id' => 'phone'))); ?>


                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">E-Mail :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="email" value="<?php echo e($contact->email); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Address :</label>
                        <div class="controls">
                            <?php echo e(Form::textarea( 'address', $contact->address, array('id' => 'address'))); ?>


                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Facebook :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="facebook" value="<?php echo e($contact->facebook); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Twitter :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="twitter" value="<?php echo e($contact->twitter); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">İntagram :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="instagram" value="<?php echo e($contact->instagram); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Linkedin :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="linkedin" value="<?php echo e($contact->linkedin); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Enlem :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="latitude"
                                   value="<?php echo e($contact->latitude); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Boylam :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="longitude"
                                   value="<?php echo e($contact->longitude); ?>"/>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.ckeditor.com/4.13.0/full/ckeditor.js"></script>
    <script>
        CKEDITOR.replace( 'phone' );
    </script>
    <script>
        CKEDITOR.replace( 'address' );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/contact/edit.blade.php ENDPATH**/ ?>