<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Task Create Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>['tasks.store'],'method'=>'POST','class'=>'widget-content nopadding']); ?>

                        <?php echo e(csrf_field()); ?>

                    <div class="control-group">
                        <label class="control-label">Name :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="name" value="<?php echo e(old('name')); ?>" />
                        </div>
                        <?php if($errors->has('name')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('name')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Description :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="description" value="<?php echo e(old('description')); ?>" />
                        </div>
                        <?php if($errors->has('description')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('description')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group" style="margin-left: 100px;">
                        <label class="control-label">Date :</label>
                        <div class="controls">
                            <input type="text"  class="date" name="task_date" value="<?php echo e(old('task_date')); ?>" />
                        </div>
                        <?php if($errors->has('task_date')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('task_date')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>
    <script>
        $('.date').datepicker({
            autoclose: true,
            dateFormat: "yy-mm-dd"
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/tasks/create.blade.php ENDPATH**/ ?>