<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Sub Menu Edit Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::model($subMenu,['route'=>['submenu.update',$subMenu->id],'method'=>'PUT','files'=>'true','class'=>'widget-content nopadding']); ?>

                    <div class="control-group">
                        <label class="control-label">Turkish Menu Name :</label>
                        <div class="controls">
                            <div class="controls">
                                <select name="menu_id" class="span11">
                                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($menu->id); ?>" <?php echo e($menu->id == old('menu_id',$subMenu->menu_id) ? 'selected' : $menu->name_tr); ?>><?php echo e($menu->name_tr); ?> </option>
                                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Turkish Menu Name :</label>
                        <div class="controls">
                            <input type="text" class="span11"  name="name_tr" value="<?php echo e($subMenu->name_tr); ?>"/>
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">English Menu Name:</label>
                        <div class="controls">
                            <input type="text" class="span11"  name="name_eng" value="<?php echo e($subMenu->name_eng); ?>"/>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/submenu/edit.blade.php ENDPATH**/ ?>