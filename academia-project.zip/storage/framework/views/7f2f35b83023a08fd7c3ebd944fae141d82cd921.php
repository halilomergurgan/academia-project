<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>File Create Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>['files.store'],'method'=>'POST','files'=>'true','class'=>'widget-content nopadding']); ?>

                        <?php echo e(csrf_field()); ?>

                    <div class="control-group">
                        <label class="control-label">File Name :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="file_name" value="<?php echo e(old('file_name')); ?>" />
                        </div>
                        <?php if($errors->has('file_name')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('file_name')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">File</label>
                        <div class="controls">
                            <input type="file" class="span11" name="file_path" />
                            <?php if($errors->has('file_path')): ?>
                                <p class="alert alert-danger">
                                    <?php echo e($errors->first('file_path')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/files/create.blade.php ENDPATH**/ ?>