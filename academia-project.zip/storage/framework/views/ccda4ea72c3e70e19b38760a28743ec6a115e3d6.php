<?php $__env->startSection('content'); ?>
    </br>
    <div class="container">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mySlides">
                <img src="<?php echo e($slider->photo_path); ?>" style="width:100%; height: 500px;">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a class="prev" onclick="plusSlides(-1)">❮</a>
        <a class="next" onclick="plusSlides(1)">❯</a>
        <div class="caption-container">
            <p id="caption"></p>
        </div>
        <div class="row" style="margin-right: -15px; margin-left: 0;">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="column">
                    <img class="demo cursor" src="<?php echo e($slider->photo_path); ?>" style="width:199px; height: 110px;; "
                         onclick="currentSlide(<?php echo e($slider->id); ?>)" alt="<?php echo e($slider->title_tr); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    <!--Start about  area -->
    <div class="about_area home-2">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="content-inner">
                        <h3 class="module-title">
                            <?php echo html_entity_decode(nl2br(e($about[0]->title_tr))); ?>

                        </h3>
                        <div class="content-desc">
                            <?php echo html_entity_decode(nl2br(e($about[0]->description_tr))); ?>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!--end about  area -->
    <!--start courses  area -->
    <div class="courses_area home-2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title">
                        <h3 class="module-title">
                            Note Uniplas <span> Güncel Eğİtİmler</span>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <!--start course single  item -->
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-sm-6 col-lg-6">
                        <div class="course_item">
                            <div class="courses_thumb">
                                <a href=""><img style="width: 280px; height: 200px;" src="<?php echo e($course->photo_path); ?>"
                                                alt=""/></a>

                            </div>
                            <div class="courses_content">
                                <h2><a href="#"><?php echo e($course->title_tr); ?></a></h2>
                                
                                <?php echo \Illuminate\Support\Str::limit($course->description_tr,100); ?>

                                </br>
                                <a href="course/<?php echo e($course->id); ?>" class="">
                                    Devamını Oku ...</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!--end courses  area -->
    <!--start priging  area -->
    <div class="priging_area home-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="title">
                                <h3 class="module-title">
                                    Note Uniplas <span>Bülten</span>
                                </h3>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="hidden-md col-sm-6 hidden-lg">
                            <div class="service_item">
                                <span class="lnr lnr-apartment"></span>
                            </div>
                        </div>
                        <!-- end service single item -->
                    </div>
                </div>
                <div class="col-lg-6 col-sm-12 col-md-6">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="title">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $magazines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $magazine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 col-sm-6 col-lg-6">
                                <div class="priging_item">
                                    <div class="priging_thumb">
                                        <a href="/journal/<?php echo e($magazine->id); ?>">
                                            <div class="atvImg">
                                                <div class="atvImg-layer" data-img="<?php echo e($magazine->photo_path); ?>"></div>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="priging_content">
                                        <br>
                                        <a href="/journal/<?php echo e($magazine->id); ?>">  <?php echo e(Str::limit(strip_tags($magazine->title_tr, 100))); ?> </a>
                                    </div>
                                </div>
                            </div>
                            <!-- end single item priging -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end priging  area -->
    <!--start news  area -->
    <div class="news_area home-2">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title">
                        <h3 class="module-title">
                            Bizden <span>Haberler</span>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <!--start single news  item -->
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="width: 100%" class="col-md-3 col-sm-6">
                        <div class="single_news_item">
                            <div class="news_thumb">
                                <a href="#"><img style="width: 280px; height: 200px;" src="<?php echo e($new->photo_path); ?>"
                                                 alt=""/></a>
                            </div>
                            <div class="news_content">

                                <p class="date"><?php echo e($new->created_at); ?></p>
                                <h2><a href="#"><?php echo e($new->title_tr); ?></a></h2>

                                <?php echo \Illuminate\Support\Str::limit($new->description_tr,100); ?>

                                </br>
                                <a href="news/<?php echo e($new->id); ?>" class="">
                                    Devamını Oku ...</a>

                            </div>
                        </div>

                    </div>
                    <!--end single news  item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/frontend/content.blade.php ENDPATH**/ ?>