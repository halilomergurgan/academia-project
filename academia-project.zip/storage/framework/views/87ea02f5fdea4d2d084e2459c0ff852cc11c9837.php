<?php $__env->startSection('content'); ?>

    <div class="single_courcse">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6">
                    <div class="single_cos_item">
                        <h2 class="single_courcse_title"><?php echo e($article->title_tr); ?></h2>
                        <br>
                        <?php echo html_entity_decode(nl2br(e($article->description_tr))); ?>

                    </div>
                </div>
                <?php if(isset($article->photo_path) || isset($article->embed_video_path)): ?>
                    <div class="col-md-4 col-sm-6">
                        <?php if(isset($article->embed_video_path)): ?>
                            <div class="met-box vedio_tutoria">
                                <figure style="width: 100%;">
                                    <?php echo html_entity_decode(nl2br(e($article->embed_video_path))); ?>

                                </figure>
                            </div>
                        <?php endif; ?>
                        <?php if($article->photo_path != '/storage/'): ?>
                            <div class="met-box">
                                <img src="<?php echo e($article->photo_path); ?>">
                            </div>
                        <?php endif; ?>
                            <?php if(isset($article->external_link)): ?>
                                <div class="met-box">
                                    <img src="<?php echo e($article->external_link); ?>">
                                </div>
                            <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/frontend/article.blade.php ENDPATH**/ ?>