<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Slider Edit Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::model($sliders,['route'=>['slider.update',$sliders->id],'method'=>'PUT','files'=>'true','class'=>'widget-content nopadding']); ?>

                    <div class="control-group">
                        <label class="control-label">Turkish Title :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="title_tr" value="<?php echo e($sliders->title_tr); ?>" />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Photo</label>
                        <div class="controls">
                            <input type="file" class="span11" name="photo_path"  value="<?php echo e($sliders->photo_path); ?>"/>
                        </div>
                        <div class="controls">
                            <img src="<?php echo e($sliders->photo_path); ?>" height="100" width="100" >
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>