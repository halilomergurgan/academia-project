<?php $__env->startSection('content'); ?>

    <div class="row-fluid">
        <div class="span">
            <div class="widget-box">
                <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
                    <h5>Teacher Create Page</h5>
                </div>
                <div class="widget-content nopadding">
                    <?php echo Form::open(['route'=>['teachers.store'],'method'=>'POST','files'=>'true','class'=>'widget-content nopadding']); ?>

                        <?php echo e(csrf_field()); ?>

                    <div class="control-group">
                        <label class="control-label">Teacher Name&Surname  :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="teach_name_tr" value="<?php echo e(old('teach_name_tr')); ?>" />
                        </div>
                        <?php if($errors->has('teach_name_tr')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('teach_name_tr')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Teacher Title :</label>
                        <div class="controls">
                            <input type="text" class="span11"  name="teach_title" value="<?php echo e(old('teach_title')); ?>" />
                        </div>
                        <?php if($errors->has('teach_title')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('teach_title')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Teacher Description TR</label>
                        <div class="controls">
                            <textarea name="teach_description_tr" id="teach_description_tr" ><?php echo e(old('teach_description_tr')); ?></textarea>
                        </div>
                        <?php if($errors->has('teach_description_tr')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('teach_description_tr')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Web Site :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="web_site" value="<?php echo e(old('web_site')); ?>" />
                        </div>
                        <?php if($errors->has('web_site')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('web_site')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Facebook :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="facebook" value="<?php echo e(old('facebook')); ?>" />
                        </div>
                        <?php if($errors->has('facebook')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('facebook')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Twitter :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="twitter" value="<?php echo e(old('twitter')); ?>" />
                        </div>
                        <?php if($errors->has('twitter')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('twitter')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">İntagram :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="instagram" value="<?php echo e(old('instagram')); ?>" />
                        </div>
                        <?php if($errors->has('instagram')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('instagram')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Linkedin :</label>
                        <div class="controls">
                            <input type="text" class="span11" name="linkedin" value="<?php echo e(old('linkedin')); ?>" />
                        </div>
                        <?php if($errors->has('linkedin')): ?>
                            <p class="alert alert-danger">
                                <?php echo e($errors->first('linkedin')); ?>

                            </p>
                        <?php endif; ?>
                    </div>
                    <div class="control-group">
                        <label class="control-label">Photo</label>
                        <div class="controls">
                            <input type="file" class="span11" name="photo_path" />
                            <?php if($errors->has('photo_path')): ?>
                                <p class="alert alert-danger">
                                    <?php echo e($errors->first('photo_path')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-success">Save</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/4.13.0/full/ckeditor.js"></script>
<script>
    CKEDITOR.replace( 'teach_description_tr' );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/teachers/create.blade.php ENDPATH**/ ?>