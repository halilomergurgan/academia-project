<?php $__env->startSection('content'); ?>

    <div style="clear: both;">
    </div>
    <div class="widget-box">
        <div class="widget-title"><span class="icon"><i class="icon-th"></i></span>
            <h5>Contact Table</h5>
        </div>
        <div class="widget-content nopadding">
            <table class="table table-bordered data-table">
                <thead>
                <tr>
                    <th>Phone</th>
                    <th>E-Mail</th>
                    <th>Address</th>
                    <th>Facebook</th>
                    <th>Twitter</th>
                    <th>İntagtam</th>
                    <th>Linkedin</th>
                    <th>Enlem</th>
                    <th>Boylam</th>
                    <th>Edit</th>
                </tr>
                </thead>
                <tbody>
                    <tr class="gradeX">
                        <td><?php echo e($contact->phone); ?></td>
                        <td><?php echo e($contact->email); ?></td>
                        <td><?php echo e($contact->address); ?></td>
                        <td><?php echo e($contact->facebook); ?></td>
                        <td><?php echo e($contact->twitter); ?></td>
                        <td><?php echo e($contact->instagram); ?></td>
                        <td><?php echo e($contact->linkedin); ?></td>
                        <td><?php echo e($contact->latitude); ?></td>
                        <td><?php echo e($contact->longitude); ?></td>

                        <td class="center"><a href="<?php echo e(route('contact.edit',$contact->id)); ?>"
                                              class="btn btn-success btn-mini">Edit</a>
                        </td>
                    </tr>

                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/admin/css/uniform.css"/>
    <link rel="stylesheet" href="/admin/css/select2.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="/admin/js/excanvas.min.js"></script>
    <script src="/admin/js/jquery.min.js"></script>
    <script src="/admin/js/jquery.ui.custom.js"></script>
    <script src="/admin/js/bootstrap.min.js"></script>
    <script src="/admin/js/jquery.dataTables.min.js"></script>
    <script src="/admin/js/matrix.tables.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\academia-project\resources\views/admin/contact/index.blade.php ENDPATH**/ ?>